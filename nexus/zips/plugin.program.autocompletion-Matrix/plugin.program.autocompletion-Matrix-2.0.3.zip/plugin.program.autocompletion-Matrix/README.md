# plugin.program.autocompletion For Matrix 
Plugin to provide autocompletion for the virtual keyboard (needs skin support)



Contains fix for  crash under Kodi  due to multiple busy dialogs. Tested with youtube and vimeo plugins on Rpi4 (Retropie / Kodi 18.7)
